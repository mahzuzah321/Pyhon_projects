from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.decorators import login_required
from .forms import *
from .forms import NewUserForm
from django.contrib.auth.forms import AuthenticationForm
from django.template import loader

from django.contrib import messages
from django.urls import reverse

from datetime import datetime
from django.db.models import Q


from .models import *

# Create your views here.
@login_required(login_url='/login')
def home(request):

    return render(request,'home.html')

@login_required(login_url='/login')
def all_emp(request):
    emps=Employee.objects.all()
    context={
        'emps':emps
    }
    print(context)
    return render(request,'all_emp.html',context)
@login_required(login_url='/login')
def add_emp(request):
    if request.method=="POST":
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        sal=int(request.POST['sal'])
        bon=int(request.POST['bon'])
        role=int(request.POST['role'])
        dept=int(request.POST['dept'])
        phone=int(request.POST['phone'])
        new_emp=Employee(first_name=first_name,last_name=last_name,sal=sal,bon=bon,phone=phone,dept_id=dept,role_id=role,hire_date=datetime.now())
        new_emp.save()
        return HttpResponse('Employee added Succesfully')



    elif request.method=='GET':

        return render(request,'add_emp.html')
    else:
        return HttpResponse("An Exception Occured")
@login_required(login_url='/login')
def remove_emp(request,emp_id=0):
    if emp_id:
        try:
            emp_to_be_removed=Employee.objects.get(id=emp_id)
            emp_to_be_removed.delete()
            return HttpResponse('Employed Removed Succesfully')
        except:
            return HttpResponse('Please enter a valid id')
    emps=Employee.objects.all()
    context={
        'emps':emps
    }
    return render(request,'remove_emp.html',context)

@login_required(login_url='/login')
def filter_emp(request):
    if request.method=="POST":
        name=request.POST['name']
        dept=request.POST['dept']
        role=request.POST['role']
        emps=Employee.objects.all()
        if name:
            emps=emps.filter(Q(first_name__icontains=name)|Q(last_name__icontains=name))
        if dept:
            emps = emps.filter(dept__name__icontains=dept)
        if role:
            emps = emps.filter(role__name__icontains=role)
        context={
            'emps':emps
        }
        return render(request,'all_emp.html',context)
    elif request.method=="GET":
        return render(request,'filter_emp.html')
    else:
        return HttpResponse('An Exception Occurred')

def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful.")
            return redirect("/")
        messages.error(request, "Unsuccessful registration. Invalid information.")
    form = NewUserForm()
    return render(request=request, template_name="register.html", context={"register_form": form})

def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect("/")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="login.html", context={"login_form":form})
@login_required(login_url='/login')
def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.")
	return redirect("/")





















